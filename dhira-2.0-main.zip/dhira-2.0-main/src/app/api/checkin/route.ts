import { NextRequest, NextResponse } from 'next/server';
import { resolveSchedulerUserId } from '@/lib/schedulerAuth';
import { runProactiveCheckin } from '@/lib/proactiveFlow';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/checkin  { userId? }  → { sent, message, ... }
 *
 * Called by Emergent on a schedule, or by the in-app "Ask Dhira to check in now"
 * button. See docs/emergent/EMERGENT_DEMO_DAY_WORKFLOW.md.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const auth = await resolveSchedulerUserId(req, body);
    if ('error' in auth) {
      return NextResponse.json({ error: auth.error }, { status: auth.status });
    }

    const result = await runProactiveCheckin(auth.uid);
    return NextResponse.json(result);
  } catch (err) {
    console.error('[api/checkin] error', err);
    return NextResponse.json({ error: 'could not generate check-in' }, { status: 500 });
  }
}
